window.onload = () => {
    document.getElementById('calculate').addEventListener('click', calculateFactorial)
    document.getElementById('putSnippet').addEventListener('click', putSnippet);
    document.getElementById('list').addEventListener('click', listAll);
    document.getElementById('languageList').addEventListener('click', getAllByLanguage);
}