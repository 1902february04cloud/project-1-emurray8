putSnippet = () => {
    let language = document.getElementById('language').value;
    let title = document.getElementById('title').value;
    let description = document.getElementById('description').value;
    let code = document.getElementById('code').value;

    let xhr = new XMLHttpRequest();

    xhr.onreadystatechange = () => {
        if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            let data = JSON.parse(xhr.responseText);
            console.log(data);
            let message = document.getElementById('addSnippetMessage');
            message.innerHTML = '<div style="opacity:1;"class="alert alert-success alert-dismissible fade show" role="alert">'+
            '<strong>Snippet successfully added!</strong>'+
            '<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
              '<span aria-hidden="true">&times;</span></button></div>'
        }
    };

    xhr.open('POST',`https://hnfz66r3rb.execute-api.us-east-1.amazonaws.com/dev/putsnippet`);

    let request =   {
                        'Language': language,
                        'Title': title,
                        'Description': description,
                        'Code': code
                    }
    xhr.send(JSON.stringify(request));
}