calculateFactorial = () => {
    //Get user input
    let number = document.getElementById('number-input').value;

    //AJAX Logic
    let xhr = new XMLHttpRequest();

    xhr.onreadystatechange = () => {
        //If the request is DONE (4), and everything is OK
        if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            //Getting JSON from response body
            let data = JSON.parse(xhr.responseText);
            console.log(data);
            let message = document.getElementById('factorialMessage');
            message.innerHTML = '<div style="opacity:1;"class="alert alert-info alert-dismissible fade show" role="alert">'+
            '<strong>The answer is '+data.body+'</strong>'+
            '<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
              '<span aria-hidden="true">&times;</span></button></div>'
        }
    };

    //Doing an HTTP call to a specific endpoint
    xhr.open('POST',`https://hnfz66r3rb.execute-api.us-east-1.amazonaws.com/dev/calculatefactorial`);

    //Sending our request
    let request = {'number': number}
    xhr.send(JSON.stringify(request));
}