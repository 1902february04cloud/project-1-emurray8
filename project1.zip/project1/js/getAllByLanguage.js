function getAllByLanguage() {
    let xhr = new XMLHttpRequest();
    let language = document.getElementById('language-query').value;
    
    xhr.onreadystatechange = () => {
        if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            let data = JSON.parse(xhr.responseText);
            console.log(data);
            populateLanguageListModal(data.body);
        }
    };

    xhr.open('POST',`https://hnfz66r3rb.execute-api.us-east-1.amazonaws.com/dev/getallbylanguage`);
    let request = {'Language': language}
    xhr.send(JSON.stringify(request));
}
function populateLanguageListModal(data) {
    let list = document.getElementById("snippetListByLanguage");
    list.innerHTML = "";
    data.forEach((snippet) => {
        let snippetElement = document.createElement("div");
        snippetElement.innerHTML = '<div><h2>'+
                                            snippet.Title+
                                        '</h2><p>'+snippet.Description+
                                        '</p><pre class="line-numbers code-toolbar language-'
                                        +snippet.Language.toLowerCase()+'"><code class="language-'+snippet.Language.toLowerCase()+
                                        '">'+snippet.Code+'</code></pre>'+snippet.Date+'</div>'
        snippetElement.className = "list-group-item";
        list.appendChild(snippetElement);
    });
    let codeElements = document.getElementsByTagName("code")
    for(let i=0;i<codeElements.length;i++){
        Prism.highlightElement(codeElements[i]);
    }
}
