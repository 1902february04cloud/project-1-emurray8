function listAll() {
    let xhr = new XMLHttpRequest();
        
    xhr.onreadystatechange = () => {
        if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            let data = JSON.parse(xhr.responseText);
            console.log(data);
            populateListModal(data.body)
        }
    };

    xhr.open('GET',` https://hnfz66r3rb.execute-api.us-east-1.amazonaws.com/dev/listall`);

    //Sending our request
    xhr.send();
}
function populateListModal(data) {
    let list = document.getElementById("snippetList");
    list.innerHTML = "";
    data.forEach((snippet) => {
        let snippetElement = document.createElement("div");
        snippetElement.innerHTML = '<div><h2>'+
                                            snippet.Title+
                                        '</h2><p>'+snippet.Description+
                                        '</p><pre class="line-numbers code-toolbar language-'
                                        +snippet.Language.toLowerCase()+'"><code class="language-'+snippet.Language.toLowerCase()+
                                        '">'+snippet.Code+'</code></pre>'+snippet.Date+'</div>'
        snippetElement.className = "list-group-item";
        list.appendChild(snippetElement);
    });
    let codeElements = document.getElementsByTagName("code")
    for(let i=0;i<codeElements.length;i++){
        Prism.highlightElement(codeElements[i]);
    }
}